<?php
/**
 * Confideline local Stripe-like payment sandbox.
 *
 * Run:
 *   php -S 127.0.0.1:8787 server.php
 *
 * This file intentionally stores only local fake payment data in runtime/state.json.
 * Do not use real Stripe keys, real card data, or production webhook URLs here.
 */

date_default_timezone_set('UTC');

$runtimeDir = __DIR__ . DIRECTORY_SEPARATOR . 'runtime';
$stateFile = $runtimeDir . DIRECTORY_SEPARATOR . 'state.json';
$baseUrl = getenv('CONFIDELINE_SANDBOX_BASE_URL') ?: 'http://127.0.0.1:8787';
$webhookSecret = getenv('CONFIDELINE_SANDBOX_WEBHOOK_SECRET') ?: 'whsec_confideline_sandbox_local_only';

if (!is_dir($runtimeDir)) {
    mkdir($runtimeDir, 0775, true);
}

function sandbox_read_state($stateFile)
{
    if (!file_exists($stateFile)) {
        return [
            'customers' => [],
            'sessions' => [],
            'payment_intents' => [],
            'charges' => [],
            'refunds' => [],
            'events' => [],
        ];
    }

    $state = json_decode(file_get_contents($stateFile), true);
    $state = is_array($state) ? $state : [
        'customers' => [],
        'sessions' => [],
        'payment_intents' => [],
        'charges' => [],
        'refunds' => [],
        'events' => [],
    ];

    foreach (['customers', 'sessions', 'payment_intents', 'charges', 'refunds', 'events'] as $key) {
        if (!isset($state[$key]) || !is_array($state[$key])) {
            $state[$key] = [];
        }
    }

    return $state;
}

function sandbox_save_state($stateFile, array $state)
{
    file_put_contents($stateFile, json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

function sandbox_json($data, $statusCode = 200)
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

function sandbox_html($html, $statusCode = 200)
{
    http_response_code($statusCode);
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

function sandbox_error($message, $statusCode = 400)
{
    sandbox_json([
        'error' => [
            'type' => 'confideline_sandbox_error',
            'message' => $message,
        ],
    ], $statusCode);
}

function sandbox_id($prefix)
{
    return $prefix . '_test_confideline_' . bin2hex(random_bytes(8));
}

function sandbox_body()
{
    $raw = file_get_contents('php://input');
    $contentType = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (stripos($contentType, 'application/json') !== false) {
        $json = json_decode($raw, true);
        return is_array($json) ? $json : [];
    }

    if (!empty($_POST)) {
        return $_POST;
    }

    $parsed = [];
    parse_str($raw, $parsed);
    return is_array($parsed) ? $parsed : [];
}

function sandbox_nested($array, array $path, $default = null)
{
    $current = $array;
    foreach ($path as $key) {
        if (!is_array($current) || !array_key_exists($key, $current)) {
            return $default;
        }
        $current = $current[$key];
    }
    return $current;
}

function sandbox_now()
{
    return time();
}

function sandbox_payment_intent_object(array $intent, array $charge = null)
{
    $charges = [];
    if ($charge !== null) {
        $charges[] = $charge;
    }

    return [
        'id' => $intent['id'],
        'object' => 'payment_intent',
        'amount' => $intent['amount'],
        'amount_received' => $intent['status'] === 'succeeded' ? $intent['amount'] : 0,
        'currency' => $intent['currency'],
        'status' => $intent['status'],
        'customer' => $intent['customer'],
        'description' => $intent['description'],
        'metadata' => $intent['metadata'],
        'created' => $intent['created'],
        'canceled_at' => isset($intent['canceled_at']) ? $intent['canceled_at'] : null,
        'cancellation_reason' => isset($intent['cancellation_reason']) ? $intent['cancellation_reason'] : null,
        'last_payment_error' => isset($intent['last_payment_error']) ? $intent['last_payment_error'] : null,
        'charges' => [
            'object' => 'list',
            'data' => $charges,
            'has_more' => false,
            'total_count' => count($charges),
        ],
    ];
}

function sandbox_event($type, array $object)
{
    return [
        'id' => sandbox_id('evt'),
        'object' => 'event',
        'api_version' => '2020-03-02',
        'created' => sandbox_now(),
        'livemode' => false,
        'pending_webhooks' => 1,
        'request' => [
            'id' => sandbox_id('req'),
            'idempotency_key' => null,
        ],
        'type' => $type,
        'data' => [
            'object' => $object,
        ],
    ];
}

function sandbox_signature($payload, $secret)
{
    $timestamp = sandbox_now();
    $signedPayload = $timestamp . '.' . $payload;
    $signature = hash_hmac('sha256', $signedPayload, $secret);
    return 't=' . $timestamp . ',v1=' . $signature;
}

function sandbox_post_webhook($url, $payload, $signature)
{
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\n", [
                'Content-Type: application/json',
                'Stripe-Signature: ' . $signature,
                'User-Agent: ConfidelineStripeSandbox/1.0',
            ]),
            'content' => $payload,
            'ignore_errors' => true,
            'timeout' => 15,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $header) {
            if (preg_match('/^HTTP\/\S+\s+(\d+)/', $header, $matches)) {
                $status = (int) $matches[1];
                break;
            }
        }
    }

    return [
        'status' => $status,
        'body' => $body,
    ];
}

function sandbox_make_charge(array $intent, $baseUrl)
{
    $chargeId = sandbox_id('ch');
    return [
        'id' => $chargeId,
        'object' => 'charge',
        'amount' => $intent['amount'],
        'amount_refunded' => 0,
        'currency' => $intent['currency'],
        'paid' => true,
        'refunded' => false,
        'status' => 'succeeded',
        'payment_intent' => $intent['id'],
        'receipt_email' => isset($intent['metadata']['email']) ? $intent['metadata']['email'] : null,
        'receipt_number' => 'CL-' . gmdate('Ymd') . '-' . strtoupper(substr($chargeId, -6)),
        'receipt_url' => rtrim($baseUrl, '/') . '/receipts/' . $chargeId . '.html',
        'created' => sandbox_now(),
        'metadata' => $intent['metadata'],
    ];
}

function sandbox_find_intent_by_session(array $state, $sessionId)
{
    if (!isset($state['sessions'][$sessionId])) {
        return [null, null];
    }
    $session = $state['sessions'][$sessionId];
    $intentId = $session['payment_intent'];
    $intent = isset($state['payment_intents'][$intentId]) ? $state['payment_intents'][$intentId] : null;
    return [$session, $intent];
}

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$state = sandbox_read_state($stateFile);

if ($method === 'GET' && $path === '/') {
    sandbox_html('<!doctype html><meta charset="utf-8"><title>Confideline Stripe Sandbox</title><body style="font-family:Arial,sans-serif;max-width:860px;margin:40px auto;line-height:1.5"><h1>Confideline Stripe Sandbox</h1><p>Local fake provider is running.</p><ul><li>POST /v1/checkout/sessions</li><li>GET /checkout/{sessionId}?outcome=success|cancel|fail</li><li>GET /v1/payment_intents/{paymentIntentId}</li><li>POST /v1/refunds</li><li>POST /sandbox/webhook</li><li>GET /sandbox/state</li></ul></body>');
}

if ($method === 'GET' && $path === '/sandbox/state') {
    sandbox_json($state);
}

if ($method === 'DELETE' && $path === '/sandbox/state') {
    $state = [
        'customers' => [],
        'sessions' => [],
        'payment_intents' => [],
        'charges' => [],
        'refunds' => [],
        'events' => [],
    ];
    sandbox_save_state($stateFile, $state);
    sandbox_json(['success' => true]);
}

if ($method === 'POST' && $path === '/v1/customers') {
    $body = sandbox_body();
    $customerId = sandbox_id('cus');
    $customer = [
        'id' => $customerId,
        'object' => 'customer',
        'created' => sandbox_now(),
        'livemode' => false,
        'email' => isset($body['email']) ? $body['email'] : null,
        'description' => isset($body['description']) ? $body['description'] : null,
        'metadata' => isset($body['metadata']) && is_array($body['metadata']) ? $body['metadata'] : [],
        'default_source' => isset($body['source']) ? $body['source'] : null,
    ];
    $state['customers'][$customerId] = $customer;
    sandbox_save_state($stateFile, $state);
    sandbox_json($customer);
}

if ($method === 'POST' && preg_match('#^/v1/customers/([^/]+)$#', $path, $matches)) {
    $customerId = $matches[1];
    if (!isset($state['customers'][$customerId])) {
        sandbox_error('Customer not found', 404);
    }
    $body = sandbox_body();
    if (isset($body['email'])) {
        $state['customers'][$customerId]['email'] = $body['email'];
    }
    if (isset($body['source'])) {
        $state['customers'][$customerId]['default_source'] = $body['source'];
    }
    if (isset($body['metadata']) && is_array($body['metadata'])) {
        $state['customers'][$customerId]['metadata'] = $body['metadata'];
    }
    sandbox_save_state($stateFile, $state);
    sandbox_json($state['customers'][$customerId]);
}

if ($method === 'GET' && preg_match('#^/v1/customers/([^/]+)$#', $path, $matches)) {
    $customerId = $matches[1];
    if (!isset($state['customers'][$customerId])) {
        sandbox_error('Customer not found', 404);
    }
    sandbox_json($state['customers'][$customerId]);
}

if ($method === 'POST' && $path === '/v1/checkout/sessions') {
    $body = sandbox_body();
    $lineItem = sandbox_nested($body, ['line_items', 0], []);
    $amount = (int) (isset($lineItem['amount']) ? $lineItem['amount'] : (isset($lineItem['price_data']['unit_amount']) ? $lineItem['price_data']['unit_amount'] : 4900));
    $currency = strtolower(isset($lineItem['currency']) ? $lineItem['currency'] : (isset($lineItem['price_data']['currency']) ? $lineItem['price_data']['currency'] : 'usd'));
    $metadata = isset($body['metadata']) && is_array($body['metadata']) ? $body['metadata'] : [];
    $sessionId = sandbox_id('cs');
    $intentId = sandbox_id('pi');
    $customer = isset($body['customer']) && $body['customer'] !== '' ? $body['customer'] : sandbox_id('cus');
    $created = sandbox_now();

    $intent = [
        'id' => $intentId,
        'amount' => $amount,
        'currency' => $currency,
        'status' => 'requires_payment_method',
        'customer' => $customer,
        'description' => 'Confideline sandbox payment',
        'metadata' => $metadata,
        'created' => $created,
    ];

    $session = [
        'id' => $sessionId,
        'object' => 'checkout.session',
        'amount_total' => $amount,
        'currency' => $currency,
        'customer' => $customer,
        'livemode' => false,
        'mode' => isset($body['mode']) ? $body['mode'] : 'payment',
        'payment_intent' => $intentId,
        'payment_method_types' => isset($body['payment_method_types']) ? array_values($body['payment_method_types']) : ['card'],
        'payment_status' => 'unpaid',
        'status' => 'open',
        'success_url' => isset($body['success_url']) ? $body['success_url'] : null,
        'cancel_url' => isset($body['cancel_url']) ? $body['cancel_url'] : null,
        'metadata' => $metadata,
        'created' => $created,
        'url' => rtrim($baseUrl, '/') . '/checkout/' . $sessionId,
    ];

    $state['payment_intents'][$intentId] = $intent;
    $state['sessions'][$sessionId] = $session;
    sandbox_save_state($stateFile, $state);
    sandbox_json($session);
}

if ($method === 'GET' && preg_match('#^/v1/checkout/sessions/([^/]+)$#', $path, $matches)) {
    $sessionId = $matches[1];
    if (!isset($state['sessions'][$sessionId])) {
        sandbox_error('Checkout session not found', 404);
    }
    sandbox_json($state['sessions'][$sessionId]);
}

if ($method === 'GET' && preg_match('#^/v1/payment_intents/([^/]+)$#', $path, $matches)) {
    $intentId = $matches[1];
    if (!isset($state['payment_intents'][$intentId])) {
        sandbox_error('Payment intent not found', 404);
    }
    $charge = null;
    foreach ($state['charges'] as $candidate) {
        if ($candidate['payment_intent'] === $intentId) {
            $charge = $candidate;
            break;
        }
    }
    sandbox_json(sandbox_payment_intent_object($state['payment_intents'][$intentId], $charge));
}

if ($method === 'GET' && preg_match('#^/checkout/([^/]+)$#', $path, $matches)) {
    $sessionId = $matches[1];
    list($session, $intent) = sandbox_find_intent_by_session($state, $sessionId);
    if (!$session || !$intent) {
        sandbox_error('Checkout session not found', 404);
    }

    $outcome = isset($_GET['outcome']) ? $_GET['outcome'] : null;
    if ($outcome === null) {
        $html = '<!doctype html><meta charset="utf-8"><title>Confideline sandbox checkout</title><body style="font-family:Arial,sans-serif;max-width:640px;margin:40px auto;line-height:1.5"><h1>Confideline sandbox checkout</h1><p>Session: <code>' . htmlspecialchars($sessionId, ENT_QUOTES, 'UTF-8') . '</code></p><p>Amount: <strong>' . htmlspecialchars(strtoupper($session['currency']), ENT_QUOTES, 'UTF-8') . ' ' . number_format($session['amount_total'] / 100, 2) . '</strong></p><p><a href="/checkout/' . rawurlencode($sessionId) . '?outcome=success">Pay successfully</a></p><p><a href="/checkout/' . rawurlencode($sessionId) . '?outcome=fail">Fail payment</a></p><p><a href="/checkout/' . rawurlencode($sessionId) . '?outcome=cancel">Cancel payment</a></p></body>';
        sandbox_html($html);
    }

    if ($outcome === 'success') {
        $intent['status'] = 'succeeded';
        $session['status'] = 'complete';
        $session['payment_status'] = 'paid';
        $charge = sandbox_make_charge($intent, $baseUrl);
        $state['payment_intents'][$intent['id']] = $intent;
        $state['sessions'][$sessionId] = $session;
        $state['charges'][$charge['id']] = $charge;
        sandbox_save_state($stateFile, $state);
        $redirectUrl = str_replace('{CHECKOUT_SESSION_ID}', rawurlencode($sessionId), $session['success_url']);
        header('Location: ' . $redirectUrl, true, 302);
        exit;
    }

    if ($outcome === 'cancel') {
        $intent['status'] = 'canceled';
        $intent['canceled_at'] = sandbox_now();
        $intent['cancellation_reason'] = 'requested_by_customer';
        $session['status'] = 'expired';
        $state['payment_intents'][$intent['id']] = $intent;
        $state['sessions'][$sessionId] = $session;
        sandbox_save_state($stateFile, $state);
        header('Location: ' . $session['cancel_url'], true, 302);
        exit;
    }

    if ($outcome === 'fail') {
        $intent['status'] = 'requires_payment_method';
        $intent['last_payment_error'] = [
            'code' => 'card_declined',
            'message' => 'Confideline sandbox simulated card decline.',
            'type' => 'card_error',
        ];
        $state['payment_intents'][$intent['id']] = $intent;
        sandbox_save_state($stateFile, $state);
        sandbox_html('<!doctype html><meta charset="utf-8"><body style="font-family:Arial,sans-serif;max-width:640px;margin:40px auto"><h1>Payment failed</h1><p>Simulated failure was saved. Use POST /sandbox/webhook with payment_intent.payment_failed to notify the site.</p></body>', 402);
    }

    sandbox_error('Unknown checkout outcome');
}

if ($method === 'POST' && $path === '/v1/refunds') {
    $body = sandbox_body();
    $intentId = isset($body['payment_intent']) ? $body['payment_intent'] : null;
    if (!$intentId || !isset($state['payment_intents'][$intentId])) {
        sandbox_error('payment_intent is required and must exist', 404);
    }

    $intent = $state['payment_intents'][$intentId];
    $amount = isset($body['amount']) ? (int) $body['amount'] : $intent['amount'];
    $charge = null;
    foreach ($state['charges'] as $candidate) {
        if ($candidate['payment_intent'] === $intentId) {
            $charge = $candidate;
            break;
        }
    }
    if (!$charge) {
        sandbox_error('Cannot refund payment without a successful charge', 400);
    }

    $refundId = sandbox_id('re');
    $refund = [
        'id' => $refundId,
        'object' => 'refund',
        'amount' => $amount,
        'currency' => $intent['currency'],
        'payment_intent' => $intentId,
        'charge' => $charge['id'],
        'status' => 'succeeded',
        'reason' => isset($body['reason']) ? $body['reason'] : 'requested_by_customer',
        'metadata' => isset($body['metadata']) && is_array($body['metadata']) ? $body['metadata'] : [],
        'created' => sandbox_now(),
    ];
    $charge['amount_refunded'] += $amount;
    $charge['refunded'] = $charge['amount_refunded'] >= $charge['amount'];
    $state['refunds'][$refundId] = $refund;
    $state['charges'][$charge['id']] = $charge;
    sandbox_save_state($stateFile, $state);
    sandbox_json($refund);
}

if ($method === 'POST' && $path === '/sandbox/webhook') {
    $body = sandbox_body();
    $type = isset($body['type']) ? $body['type'] : 'payment_intent.succeeded';
    $intentId = isset($body['payment_intent']) ? $body['payment_intent'] : null;
    $webhookUrl = isset($body['webhook_url']) ? $body['webhook_url'] : null;
    $secret = isset($body['webhook_secret']) ? $body['webhook_secret'] : $webhookSecret;

    if (!$intentId && !empty($state['payment_intents'])) {
        $keys = array_keys($state['payment_intents']);
        $intentId = end($keys);
    }
    if (!$intentId || !isset($state['payment_intents'][$intentId])) {
        sandbox_error('payment_intent is required and must exist', 404);
    }

    $intent = $state['payment_intents'][$intentId];
    if ($type === 'payment_intent.succeeded') {
        $intent['status'] = 'succeeded';
        $charge = sandbox_make_charge($intent, $baseUrl);
        $state['charges'][$charge['id']] = $charge;
    } elseif ($type === 'payment_intent.canceled') {
        $intent['status'] = 'canceled';
        $intent['canceled_at'] = sandbox_now();
        $intent['cancellation_reason'] = 'requested_by_customer';
        $charge = null;
    } elseif ($type === 'payment_intent.payment_failed') {
        $intent['status'] = 'requires_payment_method';
        $intent['last_payment_error'] = [
            'code' => 'card_declined',
            'message' => 'Confideline sandbox simulated payment failure.',
            'type' => 'card_error',
        ];
        $charge = null;
    } else {
        $charge = null;
    }

    $state['payment_intents'][$intentId] = $intent;
    $object = sandbox_payment_intent_object($intent, $charge);
    $event = sandbox_event($type, $object);
    $payload = json_encode($event, JSON_UNESCAPED_SLASHES);
    $signature = sandbox_signature($payload, $secret);
    $delivery = null;
    if ($webhookUrl) {
        $delivery = sandbox_post_webhook($webhookUrl, $payload, $signature);
    }

    $state['events'][$event['id']] = [
        'event' => $event,
        'signature' => $signature,
        'delivery' => $delivery,
    ];
    sandbox_save_state($stateFile, $state);

    sandbox_json([
        'event' => $event,
        'signature' => $signature,
        'stripe_signature' => $signature,
        'delivery' => $delivery,
    ]);
}

if ($method === 'GET' && preg_match('#^/receipts/([^/]+)\.json$#', $path, $matches)) {
    $chargeId = $matches[1];
    if (!isset($state['charges'][$chargeId])) {
        sandbox_error('Receipt not found', 404);
    }
    sandbox_json($state['charges'][$chargeId]);
}

if ($method === 'GET' && preg_match('#^/receipts/([^/]+)\.html$#', $path, $matches)) {
    $chargeId = $matches[1];
    if (!isset($state['charges'][$chargeId])) {
        sandbox_error('Receipt not found', 404);
    }
    $charge = $state['charges'][$chargeId];
    $html = '<!doctype html><meta charset="utf-8"><title>Confideline test receipt</title><body style="font-family:Arial,sans-serif;max-width:640px;margin:40px auto;line-height:1.5"><h1>Confideline test receipt</h1><p>Receipt: <strong>' . htmlspecialchars($charge['receipt_number'], ENT_QUOTES, 'UTF-8') . '</strong></p><p>Charge: <code>' . htmlspecialchars($charge['id'], ENT_QUOTES, 'UTF-8') . '</code></p><p>Payment intent: <code>' . htmlspecialchars($charge['payment_intent'], ENT_QUOTES, 'UTF-8') . '</code></p><p>Amount: <strong>' . htmlspecialchars(strtoupper($charge['currency']), ENT_QUOTES, 'UTF-8') . ' ' . number_format($charge['amount'] / 100, 2) . '</strong></p><p>Status: ' . htmlspecialchars($charge['status'], ENT_QUOTES, 'UTF-8') . '</p></body>';
    sandbox_html($html);
}

sandbox_error('Route not found: ' . $method . ' ' . $path, 404);
