# Confideline payment sandbox fixtures

Start local sandbox:
php -S 127.0.0.1:8787 server.php

Create a fake checkout session:
curl -X POST http://127.0.0.1:8787/v1/checkout/sessions \
  -d "line_items[0][amount]=4900" \
  -d "line_items[0][currency]=usd" \
  -d "mode=payment" \
  -d "success_url=http://127.0.0.1:8080/balance/stripe-success?sessionId={CHECKOUT_SESSION_ID}" \
  -d "cancel_url=http://127.0.0.1:8080/balance/stripe-cancel" \
  -d "metadata[userId]=1001" \
  -d "metadata[email]=client@example.test" \
  -d "metadata[credits]=50"

Send signed success webhook to local Confideline:
curl -X POST http://127.0.0.1:8080/balance/stripe-webhook \
  -H "Content-Type: application/json" \
  -H "Stripe-Signature: t=1780391180,v1=c0bb146ec9290929ae0864423370f97a2667342d3a9fae4f41575cfd3f02641b" \
  --data-binary @payment_intent_succeeded.webhook.json

Test cards/scenarios are controlled by outcome:
- /checkout/cs_test_confideline_0d10074da8e685f8?outcome=success
- /checkout/cs_test_confideline_0d10074da8e685f8?outcome=cancel
- /checkout/cs_test_confideline_0d10074da8e685f8?outcome=fail
