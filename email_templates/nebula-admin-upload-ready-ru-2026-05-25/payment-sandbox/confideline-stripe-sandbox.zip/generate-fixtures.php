<?php
/**
 * Generate Confideline payment sandbox fixtures without calling Stripe.
 *
 * Example:
 *   php generate-fixtures.php --out output --user-id 1001 --email user@example.test --credits 50 --amount 49.00 --currency USD
 */

date_default_timezone_set('UTC');

function arg_value(array $argv, $name, $default)
{
    $needle = '--' . $name;
    foreach ($argv as $index => $arg) {
        if ($arg === $needle && isset($argv[$index + 1])) {
            return $argv[$index + 1];
        }
        if (strpos($arg, $needle . '=') === 0) {
            return substr($arg, strlen($needle) + 1);
        }
    }
    return $default;
}

function fixture_id($prefix, $seed)
{
    return $prefix . '_test_confideline_' . substr(hash('sha256', $seed), 0, 16);
}

function fixture_write($path, $data)
{
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

function fixture_event($type, array $object, $seed)
{
    return [
        'id' => fixture_id('evt', $seed . $type),
        'object' => 'event',
        'api_version' => '2020-03-02',
        'created' => time(),
        'livemode' => false,
        'pending_webhooks' => 1,
        'type' => $type,
        'data' => [
            'object' => $object,
        ],
    ];
}

$outDir = arg_value($argv, 'out', __DIR__ . DIRECTORY_SEPARATOR . 'output');
$userId = (int) arg_value($argv, 'user-id', 1001);
$email = arg_value($argv, 'email', 'client@example.test');
$credits = (int) arg_value($argv, 'credits', 50);
$amountMajor = (float) arg_value($argv, 'amount', 49.00);
$currency = strtolower(arg_value($argv, 'currency', 'USD'));
$siteUrl = rtrim(arg_value($argv, 'site-url', 'https://confideline.com'), '/');
$seed = arg_value($argv, 'seed', 'confideline-payment-sandbox');
$webhookSecret = arg_value($argv, 'webhook-secret', 'whsec_confideline_sandbox_local_only');
$amount = (int) round($amountMajor * 100);

if (!is_dir($outDir)) {
    mkdir($outDir, 0775, true);
}

$sessionId = fixture_id('cs', $seed . 'session');
$intentId = fixture_id('pi', $seed . 'intent');
$chargeId = fixture_id('ch', $seed . 'charge');
$refundId = fixture_id('re', $seed . 'refund');
$customerId = fixture_id('cus', $seed . 'customer');
$now = time();

$metadata = [
    'orderId' => 'TEST-ORDER-1001',
    'orderGuid' => fixture_id('ord', $seed . 'order'),
    'userId' => (string) $userId,
    'email' => $email,
    'credits' => (string) $credits,
    'site' => 'confideline.com',
];

$session = [
    'id' => $sessionId,
    'object' => 'checkout.session',
    'amount_total' => $amount,
    'currency' => $currency,
    'customer' => $customerId,
    'livemode' => false,
    'mode' => 'payment',
    'payment_intent' => $intentId,
    'payment_method_types' => ['card'],
    'payment_status' => 'unpaid',
    'status' => 'open',
    'success_url' => $siteUrl . '/balance/stripe-success?sessionId={CHECKOUT_SESSION_ID}',
    'cancel_url' => $siteUrl . '/balance/stripe-cancel',
    'metadata' => $metadata,
    'created' => $now,
    'url' => 'http://127.0.0.1:8787/checkout/' . $sessionId,
];

$charge = [
    'id' => $chargeId,
    'object' => 'charge',
    'amount' => $amount,
    'amount_refunded' => 0,
    'currency' => $currency,
    'paid' => true,
    'refunded' => false,
    'status' => 'succeeded',
    'payment_intent' => $intentId,
    'receipt_email' => $email,
    'receipt_number' => 'CL-' . gmdate('Ymd') . '-TEST',
    'receipt_url' => 'http://127.0.0.1:8787/receipts/' . $chargeId . '.html',
    'created' => $now,
    'metadata' => $metadata,
];

$intentSucceeded = [
    'id' => $intentId,
    'object' => 'payment_intent',
    'amount' => $amount,
    'amount_received' => $amount,
    'currency' => $currency,
    'status' => 'succeeded',
    'customer' => $customerId,
    'description' => 'Confideline sandbox payment',
    'metadata' => $metadata,
    'created' => $now,
    'charges' => [
        'object' => 'list',
        'data' => [$charge],
        'has_more' => false,
        'total_count' => 1,
    ],
];

$intentFailed = $intentSucceeded;
$intentFailed['status'] = 'requires_payment_method';
$intentFailed['amount_received'] = 0;
$intentFailed['charges']['data'] = [];
$intentFailed['charges']['total_count'] = 0;
$intentFailed['last_payment_error'] = [
    'code' => 'card_declined',
    'message' => 'Confideline sandbox simulated card decline.',
    'type' => 'card_error',
];

$intentCanceled = $intentFailed;
$intentCanceled['status'] = 'canceled';
$intentCanceled['canceled_at'] = $now;
$intentCanceled['cancellation_reason'] = 'requested_by_customer';

$refund = [
    'id' => $refundId,
    'object' => 'refund',
    'amount' => $amount,
    'currency' => $currency,
    'payment_intent' => $intentId,
    'charge' => $chargeId,
    'status' => 'succeeded',
    'reason' => 'requested_by_customer',
    'metadata' => [
        'refundCase' => 'sandbox_full_refund',
    ],
    'created' => $now,
];

$files = [
    'checkout_session_created.json' => $session,
    'payment_intent_succeeded.webhook.json' => fixture_event('payment_intent.succeeded', $intentSucceeded, $seed),
    'payment_intent_payment_failed.webhook.json' => fixture_event('payment_intent.payment_failed', $intentFailed, $seed),
    'payment_intent_canceled.webhook.json' => fixture_event('payment_intent.canceled', $intentCanceled, $seed),
    'refund_created.json' => $refund,
    'charge_refunded.webhook.json' => fixture_event('charge.refunded', array_merge($charge, ['amount_refunded' => $amount, 'refunded' => true, 'refunds' => ['object' => 'list', 'data' => [$refund], 'total_count' => 1, 'has_more' => false]]), $seed),
    'receipt.json' => $charge,
];

foreach ($files as $name => $data) {
    fixture_write($outDir . DIRECTORY_SEPARATOR . $name, $data);
}

$payload = json_encode($files['payment_intent_succeeded.webhook.json'], JSON_UNESCAPED_SLASHES);
$timestamp = time();
$signature = hash_hmac('sha256', $timestamp . '.' . $payload, $webhookSecret);

$curl = <<<TXT
# Confideline payment sandbox fixtures

Start local sandbox:
php -S 127.0.0.1:8787 server.php

Create a fake checkout session:
curl -X POST http://127.0.0.1:8787/v1/checkout/sessions \\
  -d "line_items[0][amount]={$amount}" \\
  -d "line_items[0][currency]={$currency}" \\
  -d "mode=payment" \\
  -d "success_url={$siteUrl}/balance/stripe-success?sessionId={CHECKOUT_SESSION_ID}" \\
  -d "cancel_url={$siteUrl}/balance/stripe-cancel" \\
  -d "metadata[userId]={$userId}" \\
  -d "metadata[email]={$email}" \\
  -d "metadata[credits]={$credits}"

Send signed success webhook to local Confideline:
curl -X POST {$siteUrl}/balance/stripe-webhook \\
  -H "Content-Type: application/json" \\
  -H "Stripe-Signature: t={$timestamp},v1={$signature}" \\
  --data-binary @payment_intent_succeeded.webhook.json

Test cards/scenarios are controlled by outcome:
- /checkout/{$sessionId}?outcome=success
- /checkout/{$sessionId}?outcome=cancel
- /checkout/{$sessionId}?outcome=fail

TXT;

file_put_contents($outDir . DIRECTORY_SEPARATOR . 'curl_commands.md', $curl);

echo "Generated fixtures in {$outDir}\n";
foreach (array_keys($files) as $name) {
    echo "- {$name}\n";
}
echo "- curl_commands.md\n";
