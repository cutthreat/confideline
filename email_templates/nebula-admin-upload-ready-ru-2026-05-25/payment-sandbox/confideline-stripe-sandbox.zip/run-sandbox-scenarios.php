<?php

declare(strict_types=1);

/**
 * Runs the main Confideline payment sandbox scenarios against a running local
 * sandbox server. The script does not call the real Stripe API.
 */

$options = getopt('', [
    'base-url:',
    'site-url:',
    'webhook-secret:',
    'currency:',
    'amount:',
]);

$baseUrl = rtrim((string)($options['base-url'] ?? 'http://127.0.0.1:8787'), '/');
$siteUrl = rtrim((string)($options['site-url'] ?? 'http://127.0.0.1:8080'), '/');
$webhookSecret = (string)($options['webhook-secret'] ?? 'whsec_confideline_sandbox_local_only');
$currency = strtolower((string)($options['currency'] ?? 'usd'));
$amount = (int)round(((float)($options['amount'] ?? '49.00')) * 100);

function request(string $method, string $url, array $body = [], array $headers = []): array
{
    $content = '';
    $headerLines = $headers;

    if ($body !== []) {
        $content = http_build_query($body);
        $headerLines[] = 'Content-Type: application/x-www-form-urlencoded';
    }

    $context = stream_context_create([
        'http' => [
            'method' => $method,
            'header' => implode("\n", $headerLines),
            'content' => $content,
            'ignore_errors' => true,
            'max_redirects' => 0,
            'timeout' => 10,
        ],
    ]);

    $result = @file_get_contents($url, false, $context);
    $responseHeaders = $http_response_header ?? [];
    $status = 0;

    if (isset($responseHeaders[0]) && preg_match('/\s(\d{3})\s/', $responseHeaders[0], $matches)) {
        $status = (int)$matches[1];
    }

    return [
        'status' => $status,
        'headers' => $responseHeaders,
        'body' => $result === false ? '' : $result,
        'json' => json_decode($result === false ? '' : $result, true),
    ];
}

function expect(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function createSession(string $baseUrl, string $siteUrl, string $currency, int $amount, string $label, ?string $customerId = null): array
{
    $body = [
        'mode' => 'payment',
        'success_url' => $siteUrl . '/balance/stripe-success?sessionId={CHECKOUT_SESSION_ID}',
        'cancel_url' => $siteUrl . '/balance',
        'customer_email' => 'sandbox-' . $label . '@example.test',
        'metadata[orderId]' => (string)random_int(100000, 999999),
        'metadata[orderGuid]' => 'sandbox-' . bin2hex(random_bytes(6)),
        'metadata[userId]' => '1001',
        'line_items[0][quantity]' => '1',
        'line_items[0][price_data][currency]' => $currency,
        'line_items[0][price_data][unit_amount]' => (string)$amount,
        'line_items[0][price_data][product_data][name]' => 'Confideline credits sandbox',
    ];

    if ($customerId !== null) {
        $body['customer'] = $customerId;
    }

    $response = request('POST', $baseUrl . '/v1/checkout/sessions', $body);

    expect($response['status'] === 200, 'Checkout session was not created: HTTP ' . $response['status']);
    expect(is_array($response['json']) && isset($response['json']['id'], $response['json']['payment_intent']), 'Checkout session response is incomplete.');

    return $response['json'];
}

function getIntent(string $baseUrl, string $paymentIntentId): array
{
    $response = request('GET', $baseUrl . '/v1/payment_intents/' . rawurlencode($paymentIntentId));
    expect($response['status'] === 200, 'Payment intent was not found: HTTP ' . $response['status']);
    expect(is_array($response['json']) && isset($response['json']['status']), 'Payment intent response is incomplete.');

    return $response['json'];
}

try {
    $health = request('GET', $baseUrl . '/');
    expect($health['status'] === 200, 'Sandbox server is not available at ' . $baseUrl);

    request('DELETE', $baseUrl . '/sandbox/state');

    $customer = request('POST', $baseUrl . '/v1/customers', [
        'email' => 'sandbox-customer@example.test',
        'source' => 'tok_confideline_sandbox',
    ]);
    expect($customer['status'] === 200, 'Customer was not created: HTTP ' . $customer['status']);
    expect(isset($customer['json']['id']) && str_starts_with($customer['json']['id'], 'cus_test_confideline_'), 'Customer response is incomplete.');

    $successSession = createSession($baseUrl, $siteUrl, $currency, $amount, 'success', $customer['json']['id']);
    $successRedirect = request('GET', $baseUrl . '/checkout/' . rawurlencode($successSession['id']) . '?outcome=success');
    expect(in_array($successRedirect['status'], [302, 303], true), 'Success checkout did not redirect.');

    $succeededIntent = getIntent($baseUrl, $successSession['payment_intent']);
    expect($succeededIntent['status'] === 'succeeded', 'Success payment intent is not succeeded.');
    expect(isset($succeededIntent['charges']['data'][0]['id']), 'Success payment intent has no charge.');

    $refund = request('POST', $baseUrl . '/v1/refunds', [
        'payment_intent' => $successSession['payment_intent'],
        'reason' => 'requested_by_customer',
    ]);
    expect($refund['status'] === 200, 'Refund was not created: HTTP ' . $refund['status']);
    expect(($refund['json']['status'] ?? null) === 'succeeded', 'Refund is not succeeded.');

    $receiptUrl = $succeededIntent['charges']['data'][0]['receipt_url'] ?? null;
    expect(is_string($receiptUrl) && $receiptUrl !== '', 'Receipt URL is missing.');
    $receipt = request('GET', $receiptUrl);
    expect($receipt['status'] === 200, 'Receipt URL is not available: HTTP ' . $receipt['status']);

    $cancelSession = createSession($baseUrl, $siteUrl, $currency, $amount, 'cancel');
    $cancelRedirect = request('GET', $baseUrl . '/checkout/' . rawurlencode($cancelSession['id']) . '?outcome=cancel');
    expect(in_array($cancelRedirect['status'], [302, 303], true), 'Cancel checkout did not redirect.');
    $canceledIntent = getIntent($baseUrl, $cancelSession['payment_intent']);
    expect($canceledIntent['status'] === 'canceled', 'Cancel payment intent is not canceled.');

    $failSession = createSession($baseUrl, $siteUrl, $currency, $amount, 'fail');
    $failResponse = request('GET', $baseUrl . '/checkout/' . rawurlencode($failSession['id']) . '?outcome=fail');
    expect($failResponse['status'] === 402, 'Fail checkout did not return payment error.');
    $failedIntent = getIntent($baseUrl, $failSession['payment_intent']);
    expect($failedIntent['status'] === 'requires_payment_method', 'Failed payment intent has wrong status.');
    expect(isset($failedIntent['last_payment_error']['message']), 'Failed payment intent has no error details.');

    $webhook = request('POST', $baseUrl . '/sandbox/webhook', [
        'type' => 'payment_intent.succeeded',
        'payment_intent' => $successSession['payment_intent'],
        'webhook_url' => $siteUrl . '/balance/stripe-webhook',
        'webhook_secret' => $webhookSecret,
    ]);
    expect($webhook['status'] === 200, 'Webhook fixture was not generated: HTTP ' . $webhook['status']);
    expect(($webhook['json']['event']['type'] ?? null) === 'payment_intent.succeeded', 'Webhook event type is wrong.');
    expect(isset($webhook['json']['stripe_signature']), 'Webhook signature is missing.');

    $state = request('GET', $baseUrl . '/sandbox/state');
    expect($state['status'] === 200, 'State endpoint is not available.');
    expect(count($state['json']['customers'] ?? []) === 1, 'Scenario state should contain 1 customer.');
    expect(count($state['json']['sessions'] ?? []) === 3, 'Scenario state should contain 3 sessions.');
    expect(count($state['json']['refunds'] ?? []) === 1, 'Scenario state should contain 1 refund.');

    echo "Confideline payment sandbox scenarios passed.\n";
    echo "Customer: {$customer['json']['id']}\n";
    echo "Success session: {$successSession['id']}\n";
    echo "Cancel session: {$cancelSession['id']}\n";
    echo "Fail session: {$failSession['id']}\n";
    echo "Refund: {$refund['json']['id']}\n";
    echo "Webhook type: {$webhook['json']['event']['type']}\n";
    exit(0);
} catch (Throwable $exception) {
    fwrite(STDERR, "Confideline payment sandbox scenarios failed: {$exception->getMessage()}\n");
    exit(1);
}
