# Единый стандарт event/template naming

Правило: backend `event_name` и backend title/constant являются источником имени. `template_key` и папка должны быть максимально похожи на backend-событие; маркетинговый смысл остается в subject, описании сценария и тексте письма.

| # | Backend title | Constant | event_name | template_key | folder | Статус |
|---:|---|---|---|---|---|---|
| 0 | User registration | `USER_REGISTER` | `user.register` | `user_registration` | `templates/00_user_registration` | existing_backend_event |
| 1 | Email confirmation | `USER_EMAIL_CONFIRMATION` | `user.email_confirmation` | `email_confirmation` | `templates/01_email_confirmation` | existing_backend_event |
| 2 | Password recovery | `USER_PASSWORD_RECOVERY` | `user.password_recovery` | `user_password_recovery` | `templates/02_user_password_recovery` | new_backend_event |
| 3 | Security change | `SECURITY_CHANGE` | `security.security_change` | `security_change` | `templates/03_security_change` | new_backend_event |
| 4 | Successful payment | `PAYMENT_SUCCESS` | `payment.success` | `payment_success` | `templates/04_payment_success` | existing_backend_event |
| 5 | Payment error | `PAYMENT_ERROR` | `payment.error` | `payment_error` | `templates/05_payment_error` | existing_backend_event |
| 6 | Payment initialized | `PAYMENT_INIT` | `payment.init` | `payment_init` | `templates/06_payment_init` | existing_backend_event |
| 7 | No first chat message | `MESSAGE_NO_FIRST_CHAT_MESSAGE` | `message.no_first_chat_message` | `message_no_first_chat_message` | `templates/07_message_no_first_chat_message` | new_backend_event |
| 8 | Answer delayed | `MESSAGE_ANSWER_DELAYED` | `message.answer_delayed` | `message_answer_delayed` | `templates/08_message_answer_delayed` | new_backend_event |
| 9 | New message received | `MESSAGE_RECEIVED` | `message.received` | `message_received` | `templates/09_message_received` | existing_backend_event |
| 10 | Support ticket opened | `SUPPORT_TICKET_OPENED` | `support.ticket.opened` | `support_ticket_opened` | `templates/10_support_ticket_opened` | new_backend_event |
| 11 | Support message received | `SUPPORT_MESSAGE_RECEIVED` | `support.message.received` | `support_message_received` | `templates/11_support_message_received` | existing_backend_event |
| 12 | Payment refund | `PAYMENT_REFUND` | `payment.refund` | `payment_refund` | `templates/12_payment_refund` | existing_backend_event |
| 13 | Payment refund update | `PAYMENT_REFUND_UPDATE` | `payment.refund.update` | `payment_refund_update` | `templates/13_payment_refund_update` | new_backend_event |
| 14 | Advisor followup offer | `ADVISOR_FOLLOWUP_OFFER` | `advisor.followup.offer` | `advisor_followup_offer` | `templates/14_advisor_followup_offer` | new_backend_event |
| 15 | Review request | `REVIEW_REQUEST` | `review.request` | `review_request` | `templates/15_review_request` | new_backend_event |
| 16 | Chat saved | `MESSAGE_CHAT_SAVED` | `message.chat_saved` | `message_chat_saved` | `templates/16_message_chat_saved` | new_backend_event |
| 17 | Support safety notice | `SUPPORT_SAFETY_NOTICE` | `support.safety_notice` | `support_safety_notice` | `templates/17_support_safety_notice` | new_backend_event |
| 18 | User age restricted | `USER_AGE_RESTRICTED` | `user.age_restricted` | `user_age_restricted` | `templates/18_user_age_restricted` | new_backend_event |
