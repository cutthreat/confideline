# Инструкция для верстки HTML e-mail шаблонов

Эти шаблоны отправляются как e-mail, а не открываются как обычная HTML-страница в браузере. Верстка должна быть рассчитана на почтовые клиенты: Gmail, Apple Mail/iOS Mail, Outlook desktop, Outlook web, Yahoo, Mail.ru/укр.почта и мобильные приложения.

## Главный принцип

- Верстать нужно как HTML e-mail: таблицами, inline CSS и простыми поддерживаемыми свойствами.
- Нельзя ориентироваться только на preview в браузере. Браузер почти всегда покажет лучше, чем реальный почтовый клиент.
- Важный критерий качества: письмо должно быть читабельным и аккуратным даже там, где часть CSS не поддерживается.

## Базовая структура

- Использовать `<table role="presentation">` для сетки, карточек, колонок и отступов.
- Основной контейнер держать в пределах `600px`.
- Внешний фон задавать через `bgcolor` и inline `background`.
- Основные стили дублировать inline на самих элементах.
- `<style>` можно использовать только для progressive enhancement: мобильные media queries, скрытый preheader, дополнительные классы. Критичные стили должны быть inline.
- Не использовать полноценный page layout как для сайта: `div`-сетки, flex, grid, fixed/sticky, absolute positioning.

## CSS, который нельзя считать надежным

Не использовать для критичного внешнего вида:

- `display:flex`, `display:grid`
- `position:absolute`, `position:fixed`
- CSS animations/transitions
- JavaScript
- external CSS-файлы
- web fonts как обязательный элемент дизайна
- CSS variables
- complex selectors
- gradients как единственный способ показать фон
- background images без Outlook fallback
- `border-radius` как обязательный элемент в Outlook
- `overflow:hidden` для обрезки радиусов в Outlook

## Outlook desktop

Outlook desktop/classic на Windows использует Word rendering engine. Это самый проблемный клиент.

Что учитывать:

- `border-radius` на `<table>` и `<a>` может не работать.
- `overflow:hidden` на таблицах может не работать.
- Современные CSS-свойства часто игнорируются.
- Rounded button нужно делать через VML fallback.
- Rounded card corners в Outlook либо делать через сложный VML wrapper, либо считать progressive enhancement: в Outlook карточка может быть с квадратными углами.

## Кнопки

Обычная HTML-кнопка с `border-radius` недостаточна для Outlook. Для CTA-кнопок нужен bulletproof button: VML для Outlook и обычная ссылка для остальных клиентов.

Пример:

```html
<table role="presentation" cellpadding="0" cellspacing="0" border="0">
  <tr>
    <td align="center">
      <!--[if mso]>
      <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml"
        xmlns:w="urn:schemas-microsoft-com:office:word"
        href="{{siteUrl}}"
        style="height:48px;v-text-anchor:middle;width:170px;"
        arcsize="50%"
        strokecolor="#6f3bd6"
        fillcolor="#6f3bd6">
        <w:anchorlock/>
        <center style="color:#ffffff;font-family:Arial,sans-serif;font-size:15px;font-weight:700;">
          Open account
        </center>
      </v:roundrect>
      <![endif]-->
      <!--[if !mso]><!-- -->
      <a href="{{siteUrl}}"
         target="_blank"
         style="display:inline-block;background:#6f3bd6;color:#ffffff;font-family:Arial,sans-serif;font-size:15px;line-height:19px;font-weight:700;text-decoration:none;text-align:center;padding:15px 26px;border-radius:999px;">
        Open account
      </a>
      <!--<![endif]-->
    </td>
  </tr>
</table>
```

Для каждого основного CTA нужно использовать такой подход.

## Карточки и закругления

- Если дизайн требует закругленную карточку, можно оставить `border-radius` для Gmail/Apple Mail/modern Outlook.
- Нужно понимать, что в Outlook classic углы могут стать квадратными. Это допустимо, если письмо остается аккуратным.
- Не строить критичный дизайн на `overflow:hidden` и радиусах таблицы.
- Если закругленная карточка обязательна именно в Outlook, нужно отдельно делать VML-обертку. Это усложняет шаблон и должно согласовываться отдельно.

## Изображения

- У всех изображений должны быть `width`, `height`, `alt`, `border="0"` и inline `display:block`.
- Нельзя полагаться на то, что картинки всегда загрузятся. Многие клиенты блокируют картинки по умолчанию.
- Логотип/иконки не должны быть единственным носителем смысла.
- Для ретины можно использовать изображение 2x, но задавать реальный отображаемый размер через `width`.

Пример:

```html
<img src="{{logoUrl}}"
     width="120"
     height="40"
     alt="{{siteName}}"
     border="0"
     style="display:block;width:120px;height:auto;border:0;outline:none;text-decoration:none;">
```

## Текст и типографика

- Использовать web-safe fonts: `Arial`, `Helvetica`, `Georgia`, `Times New Roman`.
- Не рассчитывать на подключение Google Fonts.
- Размер основного текста: 14-17px.
- Line-height задавать явно.
- Цвет текста должен иметь нормальный контраст.
- Не делать текст картинкой.
- Все длинные значения должны переноситься: email, URL, имена, суммы, номера заказов.

## Мобильная адаптация

- Основной макет должен быть mobile-first или корректно сжиматься до 320px.
- Media queries можно использовать, но не делать их единственным способом нормального отображения.
- Кнопки на мобильном можно делать `display:block;width:100%`, но базовая кнопка должна выглядеть нормально и без media query.
- Не использовать две сложные колонки, если их нельзя безопасно превратить в одну колонку.

## Dark mode

- Gmail, Apple Mail и Outlook могут менять цвета в dark mode.
- Нельзя полагаться только на очень светлый фон и очень темный текст без проверки.
- Важные кнопки должны оставаться читаемыми при инверсии цветов.
- Логотипы и иконки должны иметь версию, которая не пропадает на темном фоне, или иметь безопасный контейнер.

## Что запрещено

- JavaScript.
- Forms.
- Video/audio как обязательный контент.
- iframe.
- SVG как единственный важный визуальный элемент.
- External CSS.
- Layout через flex/grid.
- Скрытые интерактивные элементы, которые работают только в браузере.
- Критичный контент только в background-image.

## Переменные шаблона

Переменные должны оставаться в формате проекта:

- `{{siteName}}`
- `{{siteUrl}}`
- `{{userName}}`
- `{{supportEmail}}`
- `{{legalMerchantName}}`
- `{{termsUrl}}`
- `{{privacyUrl}}`
- `{{refundPolicyUrl}}`

Нельзя менять имена переменных, добавлять пробелы внутри имени или переводить их.

Правильно:

```html
<a href="{{siteUrl}}">Open account</a>
```

Неправильно:

```html
<a href="{{ site_url }}">Open account</a>
```

## Preheader

В каждом HTML-шаблоне должен быть preheader в начале письма.

Пример:

```html
<span style="display:none!important;visibility:hidden;opacity:0;color:transparent;height:0;width:0;overflow:hidden;mso-hide:all;">
  Your short preheader text.
</span>
```

## Проверка перед передачей шаблона

Минимальный QA:

- Открыть HTML в браузере только как предварительный preview.
- Отправить реальный `.eml` или тестовое письмо.
- Проверить Gmail web.
- Проверить Gmail mobile app.
- Проверить Apple Mail/iOS Mail, если доступно.
- Проверить Outlook web.
- Проверить Outlook desktop/classic на Windows.
- Проверить письмо с отключенными изображениями.
- Проверить ширину 320px.
- Проверить длинные значения переменных: длинное имя, длинный email, длинный URL.
- Проверить dark mode хотя бы в Gmail/Apple Mail/Outlook, если доступно.

## Что считается допустимой разницей

Допустимо:

- В Outlook classic карточка может быть без закругленных углов.
- В Outlook classic могут отличаться точные отступы на несколько пикселей.
- Web fonts могут замениться на Arial/Helvetica.
- Некоторые декоративные эффекты могут исчезнуть.

Недопустимо:

- Кнопка становится обычной синей ссылкой.
- Текст накладывается друг на друга.
- Основной контент выходит за экран на мобильном.
- Ссылки или кнопки невозможно нажать.
- Важный текст пропадает в dark mode.
- Письмо получает старый/лишний header/footer.
- Без картинок письмо теряет смысл.

## Формат результата

Для каждого языка шаблона нужно передавать:

- `subject_email.txt`
- `preheader_note.txt`
- `body_email_html.html`
- `body_email_txt.txt`
- `comment_about.txt`
- `admin-meta.json`

`body_email_html.html` должен быть email-safe HTML-фрагментом. Не добавлять `<!doctype>`, `<html>`, `<head>`, `<body>`, если это отдельно не согласовано с backend.

