(function (window, $) {
    'use strict';

    if (!$ || !window.bootbox) {
        return;
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function inferVariant(message, fallbackType) {
        var source = String(message || '').toLowerCase();

        if (fallbackType) {
            return fallbackType;
        }

        if (/(delete|remove|uninstall|block|ban|clear|purge|убрать|удал|блок|очист)/i.test(source)) {
            return 'danger';
        }

        if (/(confirm|approve|verification|verify|grant|restore|подтверд|вериф|разреш|publish|approve)/i.test(source)) {
            return 'success';
        }

        return 'info';
    }

    function getMeta(type) {
        if (type === 'danger') {
            return {
                title: 'Confirm action',
                alertClass: 'alert-danger',
                confirmClass: 'btn-danger',
                icon: 'fa-ban'
            };
        }

        if (type === 'success') {
            return {
                title: 'Confirm action',
                alertClass: 'alert-success',
                confirmClass: 'btn-success',
                icon: 'fa-check'
            };
        }

        return {
            title: 'Confirm action',
            alertClass: 'alert-info',
            confirmClass: 'btn-primary',
            icon: 'fa-info-circle'
        };
    }

    function buildBody(message, type, hint) {
        var meta = getMeta(type);
        var html = '<div class="alert ' + meta.alertClass + '" role="alert">' +
            '<i class="icon fa ' + meta.icon + '"></i>' +
            escapeHtml(message) +
            '</div>';

        if (hint) {
            html += '<p class="text-muted">' + escapeHtml(hint) + '</p>';
        }

        return html;
    }

    function showConfirm(options) {
        var settings = $.extend({
            message: '',
            title: '',
            type: null,
            confirmLabel: 'OK',
            cancelLabel: 'Cancel',
            hint: '',
            onConfirm: $.noop,
            onCancel: $.noop
        }, options || {});
        var type = inferVariant(settings.message, settings.type);
        var meta = getMeta(type);

        return window.bootbox.dialog({
            title: escapeHtml(settings.title || meta.title),
            message: buildBody(settings.message, type, settings.hint),
            closeButton: true,
            onEscape: function () {
                settings.onCancel();
            },
            buttons: {
                cancel: {
                    label: escapeHtml(settings.cancelLabel),
                    className: 'btn btn-default',
                    callback: function () {
                        settings.onCancel();
                    }
                },
                confirm: {
                    label: escapeHtml(settings.confirmLabel),
                    className: 'btn ' + meta.confirmClass,
                    callback: function () {
                        settings.onConfirm();
                    }
                }
            }
        });
    }

    function showAlert(options) {
        var settings = $.extend({
            message: '',
            title: '',
            type: 'info',
            buttonLabel: 'OK',
            hint: '',
            onClose: $.noop
        }, options || {});
        var type = inferVariant(settings.message, settings.type);
        var meta = getMeta(type);

        return window.bootbox.dialog({
            title: escapeHtml(settings.title || meta.title),
            message: buildBody(settings.message, type, settings.hint),
            closeButton: true,
            onEscape: function () {
                settings.onClose();
            },
            buttons: {
                confirm: {
                    label: escapeHtml(settings.buttonLabel),
                    className: 'btn ' + meta.confirmClass,
                    callback: function () {
                        settings.onClose();
                    }
                }
            }
        });
    }

    window.ConfidelineAdminDialogs = {
        confirm: showConfirm,
        alert: showAlert,
        inferVariant: inferVariant
    };

    if (window.yii) {
        window.yii.confirm = function (message, ok, cancel) {
            showConfirm({
                title: 'Confirm action',
                message: message,
                type: inferVariant(message),
                onConfirm: function () {
                    if (typeof ok === 'function') {
                        ok();
                    }
                },
                onCancel: function () {
                    if (typeof cancel === 'function') {
                        cancel();
                    }
                }
            });

            return false;
        };
    }
})(window, window.jQuery);
