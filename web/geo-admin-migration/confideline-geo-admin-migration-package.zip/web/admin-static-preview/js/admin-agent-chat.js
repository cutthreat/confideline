(function ($) {
    'use strict';

    var root = document.getElementById('admin-agent-chat');
    if (!root || !window.AdminAgentChatConfig) {
        return;
    }

    var config = window.AdminAgentChatConfig || {};
    var endpoints = config.endpoints || {};
    if (!endpoints.conversations || !endpoints.messages || !endpoints.send) {
        return;
    }

    var state = {
        conversations: [],
        selectedId: null,
        currentMessages: [],
        pollTimer: null,
        isLoadingConversations: false,
        isLoadingMessages: false,
        isSending: false
    };

    var defaultText = {
        emptyValue: '-',
        selectConversation: 'Select conversation',
        unreadPrefix: 'Unread: ',
        statusConnected: 'Connected',
        statusUpdating: 'Updating...',
        statusIssue: 'Connection issue',
        noConversationMessages: 'Select conversation to load messages',
        noMessagesInConversation: 'No messages in this conversation',
        errorLoadMessages: 'Could not load messages',
        errorLoadConversations: 'Could not load conversations',
        errorMessageTooLong: 'Message is too long',
        errorInvalidSender: 'Invalid sender',
        errorSendMessage: 'Could not send message'
    };
    var TEXT = $.extend({}, defaultText, config.labels || {});

    var dom = {
        $connectionStatus: $('[data-role="connection-status"]', root),
        $connectionLabel: $('[data-role="connection-label"]', root),
        $conversationList: $('[data-role="conversation-list"]', root),
        $conversationEmpty: $('[data-role="conversation-empty"]', root),
        $conversationCount: $('[data-role="conversation-count"]', root),
        $searchForm: $('[data-role="search-form"]', root),
        $searchInput: $('[data-role="search-input"]', root),
        $refresh: $('[data-role="refresh"]', root),
        $messageList: $('[data-role="message-list"]', root),
        $route: $('[data-role="conversation-route"]', root),
        $routeSubtitle: $('[data-role="conversation-subtitle"]', root),
        $unreadBadge: $('[data-role="unread-badge"]', root),
        $sendForm: $('[data-role="send-form"]', root),
        $sendButton: $('[data-role="send-button"]', root),
        $messageInput: $('[data-role="message-input"]', root),
        $senderSelect: $('[data-role="sender-select"]', root),
        $metaAName: $('[data-role="meta-a-name"]', root),
        $metaAId: $('[data-role="meta-a-id"]', root),
        $metaAUsername: $('[data-role="meta-a-username"]', root),
        $metaAStatus: $('[data-role="meta-a-status"]', root),
        $metaBName: $('[data-role="meta-b-name"]', root),
        $metaBId: $('[data-role="meta-b-id"]', root),
        $metaBUsername: $('[data-role="meta-b-username"]', root),
        $metaBStatus: $('[data-role="meta-b-status"]', root),
        $metaLastMessage: $('[data-role="meta-last-message"]', root),
        $metaLastTime: $('[data-role="meta-last-time"]', root)
    };

    function showNotification(type, message) {
        if (typeof window.Messenger === 'function') {
            window.Messenger().post({
                message: message,
                type: type || 'info',
                hideAfter: 4,
                hideOnNavigate: true
            });
            return;
        }

        if (type === 'error' && window.ConfidelineAdminDialogs && typeof window.ConfidelineAdminDialogs.alert === 'function') {
            window.ConfidelineAdminDialogs.alert({
                title: 'Connection issue',
                message: message,
                type: 'danger'
            });
            return;
        }

        if (type === 'error' && window.bootbox && typeof window.bootbox.alert === 'function') {
            window.bootbox.alert(message);
        }
    }

    function reportConnectionError(message) {
        showNotification('error', message);
        updateConnectionStatus('error', TEXT.statusIssue);
    }

    function resetMessagesView(messageText) {
        state.currentMessages = [];
        dom.$messageList.html('<div class="aac__empty aac__empty--messages">' + escapeHtml(messageText) + '</div>');
    }

    function getCsrfToken() {
        var token = $('meta[name="csrf-token"]').attr('content');
        return token || '';
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatLabelDate(timestamp, fallbackLabel) {
        if (fallbackLabel) {
            return fallbackLabel;
        }
        if (!timestamp) {
            return TEXT.emptyValue;
        }
        try {
            var date = new Date(parseInt(timestamp, 10) * 1000);
            return date.toLocaleString();
        } catch (e) {
            return TEXT.emptyValue;
        }
    }

    function formatDay(timestamp) {
        if (!timestamp) {
            return '';
        }
        try {
            var date = new Date(parseInt(timestamp, 10) * 1000);
            return date.toLocaleDateString();
        } catch (e) {
            return '';
        }
    }

    function updateConnectionStatus(mode, label) {
        dom.$connectionStatus.removeClass('aac__status--warning aac__status--error');

        if (mode === 'warning') {
            dom.$connectionStatus.addClass('aac__status--warning');
        } else if (mode === 'error') {
            dom.$connectionStatus.addClass('aac__status--error');
        }

        if (label) {
            dom.$connectionLabel.text(label);
        }
    }

    function compareConversations(a, b) {
        var aId = a && a.lastMessage ? parseInt(a.lastMessage.id || 0, 10) : 0;
        var bId = b && b.lastMessage ? parseInt(b.lastMessage.id || 0, 10) : 0;
        return bId - aId;
    }

    function findConversationById(conversationId) {
        var index;
        for (index = 0; index < state.conversations.length; index += 1) {
            if (state.conversations[index].id === conversationId) {
                return state.conversations[index];
            }
        }

        return null;
    }

    function getCurrentConversation() {
        if (!state.selectedId) {
            return null;
        }

        return findConversationById(state.selectedId);
    }

    function getUserStatusLabel(user) {
        if (!user) {
            return TEXT.emptyValue;
        }
        if (user.isBlocked) {
            return 'Blocked';
        }
        return user.isOnline ? 'Online' : 'Offline';
    }

    function renderMeta(conversation) {
        if (!conversation) {
            dom.$metaAName.text(TEXT.emptyValue);
            dom.$metaAId.text(TEXT.emptyValue);
            dom.$metaAUsername.text(TEXT.emptyValue);
            dom.$metaAStatus.text(TEXT.emptyValue);
            dom.$metaBName.text(TEXT.emptyValue);
            dom.$metaBId.text(TEXT.emptyValue);
            dom.$metaBUsername.text(TEXT.emptyValue);
            dom.$metaBStatus.text(TEXT.emptyValue);
            dom.$metaLastMessage.text(TEXT.emptyValue);
            dom.$metaLastTime.text(TEXT.emptyValue);
            return;
        }

        dom.$metaAName.text(conversation.userA.name || conversation.userA.username || TEXT.emptyValue);
        dom.$metaAId.text(conversation.userA.id || TEXT.emptyValue);
        dom.$metaAUsername.text(conversation.userA.username || TEXT.emptyValue);
        dom.$metaAStatus.text(getUserStatusLabel(conversation.userA));

        dom.$metaBName.text(conversation.userB.name || conversation.userB.username || TEXT.emptyValue);
        dom.$metaBId.text(conversation.userB.id || TEXT.emptyValue);
        dom.$metaBUsername.text(conversation.userB.username || TEXT.emptyValue);
        dom.$metaBStatus.text(getUserStatusLabel(conversation.userB));

        dom.$metaLastMessage.text((conversation.lastMessage && conversation.lastMessage.text) ? conversation.lastMessage.text : TEXT.emptyValue);
        dom.$metaLastTime.text(formatLabelDate(
            conversation.lastMessage ? conversation.lastMessage.createdAt : null,
            conversation.lastMessage ? conversation.lastMessage.createdAtLabel : null
        ));
    }

    function renderConversationHeader(conversation) {
        if (!conversation) {
            dom.$route.text(TEXT.selectConversation);
            dom.$routeSubtitle.text(TEXT.emptyValue);
            dom.$unreadBadge.text(TEXT.unreadPrefix + '0');
            return;
        }

        dom.$route.text((conversation.userA.name || conversation.userA.username) + ' -> ' + (conversation.userB.name || conversation.userB.username));
        dom.$routeSubtitle.text(
            '#' + conversation.userA.id + ' / #' + conversation.userB.id
        );
        dom.$unreadBadge.text(TEXT.unreadPrefix + parseInt(conversation.unreadCount || 0, 10));
    }

    function renderSenderSelect(conversation) {
        var html = '';
        var currentSenderId = parseInt(dom.$senderSelect.val() || 0, 10);
        var preferred = null;
        var optionA;
        var optionB;

        if (!conversation) {
            dom.$senderSelect.html('');
            dom.$senderSelect.prop('disabled', true);
            return;
        }

        optionA = (conversation.userA.name || conversation.userA.username || ('User #' + conversation.userA.id)) + ' (#' + conversation.userA.id + ')';
        optionB = (conversation.userB.name || conversation.userB.username || ('User #' + conversation.userB.id)) + ' (#' + conversation.userB.id + ')';
        preferred = conversation.lastMessage ? parseInt(conversation.lastMessage.fromUserId || 0, 10) : 0;

        html += '<option value="' + escapeHtml(conversation.userA.id) + '">' + escapeHtml(optionA) + '</option>';
        html += '<option value="' + escapeHtml(conversation.userB.id) + '">' + escapeHtml(optionB) + '</option>';
        dom.$senderSelect.html(html);
        dom.$senderSelect.prop('disabled', false);

        if (currentSenderId === parseInt(conversation.userA.id, 10) || currentSenderId === parseInt(conversation.userB.id, 10)) {
            dom.$senderSelect.val(String(currentSenderId));
        } else if (preferred === parseInt(conversation.userA.id, 10) || preferred === parseInt(conversation.userB.id, 10)) {
            dom.$senderSelect.val(String(preferred));
        } else {
            dom.$senderSelect.val(String(conversation.userA.id));
        }
    }

    function setComposerEnabled(enabled) {
        dom.$messageInput.prop('disabled', !enabled);
        dom.$sendButton.prop('disabled', !enabled);
        if (!enabled) {
            dom.$messageInput.val('');
        }
    }

    function renderMessages(messages, conversation) {
        var html = '';
        var selectedSenderId = parseInt(dom.$senderSelect.val() || 0, 10);
        var i;
        var message;
        var isOutgoing;
        var dayLabel;
        var previousDay = null;
        var senderName;
        var text;
        var attachments;
        var j;
        var attachment;
        var imageUrl;
        var fullUrl;

        if (!conversation) {
            resetMessagesView(TEXT.noConversationMessages);
            return;
        }

        if (!messages || !messages.length) {
            resetMessagesView(TEXT.noMessagesInConversation);
            return;
        }

        state.currentMessages = messages.slice();

        if (!selectedSenderId && conversation) {
            selectedSenderId = parseInt(conversation.userA.id, 10);
        }

        for (i = 0; i < messages.length; i += 1) {
            message = messages[i];
            dayLabel = formatDay(message.createdAt);
            if (dayLabel !== previousDay) {
                previousDay = dayLabel;
                html += '<div class="aac__day-divider">' + escapeHtml(dayLabel) + '</div>';
            }

            isOutgoing = parseInt(message.fromUserId, 10) === selectedSenderId;
            senderName = (message.sender && message.sender.name) ? message.sender.name : ('User #' + message.fromUserId);
            text = message.text || '';
            attachments = message.attachments || [];

            html += '<article class="aac__message ' + (isOutgoing ? 'aac__message--outgoing' : 'aac__message--incoming') + '">';
            html += '<div class="aac__message-card">';
            html += '<header class="aac__message-head">';
            html += '<span>' + escapeHtml(senderName) + '</span>';
            html += '<span>' + escapeHtml(formatLabelDate(message.createdAt, message.createdAtLabel)) + '</span>';
            html += '</header>';

            if (text.length) {
                html += '<div class="aac__message-text">' + escapeHtml(text).replace(/\n/g, '<br>') + '</div>';
            }

            if (attachments.length) {
                html += '<div class="aac__attachments">';
                for (j = 0; j < attachments.length; j += 1) {
                    attachment = attachments[j];
                    imageUrl = attachment.thumbnail || attachment.url || '';
                    fullUrl = attachment.url || '#';
                    if (imageUrl) {
                        html += '<a href="' + escapeHtml(fullUrl) + '" rel="noopener noreferrer" target="_blank">';
                        html += '<img alt="attachment" class="aac__attachment-image" src="' + escapeHtml(imageUrl) + '">';
                        html += '</a>';
                    }
                }
                html += '</div>';
            }

            html += '</div>';
            html += '</article>';
        }

        dom.$messageList.html(html);
        dom.$messageList.scrollTop(dom.$messageList[0].scrollHeight);
    }

    function renderConversationList() {
        var html = '';
        var i;
        var conversation;
        var isActive;
        var unreadCount;
        var messageText;
        var route;

        for (i = 0; i < state.conversations.length; i += 1) {
            conversation = state.conversations[i];
            isActive = state.selectedId === conversation.id;
            unreadCount = parseInt(conversation.unreadCount || 0, 10);
            messageText = conversation.lastMessage && conversation.lastMessage.text ? conversation.lastMessage.text : '';
            route = (conversation.userA.name || conversation.userA.username) + ' -> ' + (conversation.userB.name || conversation.userB.username);

            html += '<li class="list-group-item aac__conversation' + (isActive ? ' active' : '') + '"';
            html += ' data-conversation-id="' + escapeHtml(conversation.id) + '"';
            html += ' data-user-a="' + escapeHtml(conversation.userA.id) + '"';
            html += ' data-user-b="' + escapeHtml(conversation.userB.id) + '">';
            html += '<div class="aac__conversation-main">';
            html += '<div class="aac__conversation-names">';
            html += '<div class="aac__conversation-route">' + escapeHtml(route) + '</div>';
            html += '<div class="aac__conversation-text">' + escapeHtml(messageText || TEXT.emptyValue) + '</div>';
            html += '</div>';
            html += '<div class="aac__conversation-meta">';
            html += '<div>' + escapeHtml(formatLabelDate(
                conversation.lastMessage ? conversation.lastMessage.createdAt : null,
                conversation.lastMessage ? conversation.lastMessage.createdAtLabel : null
            )) + '</div>';
            if (unreadCount > 0) {
                html += '<div class="aac__conversation-unread"><span class="label label-danger">' + unreadCount + '</span></div>';
            }
            html += '</div>';
            html += '</div>';
            html += '</li>';
        }

        dom.$conversationList.html(html);
        dom.$conversationCount.text(state.conversations.length);
        dom.$conversationEmpty.toggle(state.conversations.length === 0);
    }

    function upsertConversation(conversation) {
        var i;
        if (!conversation || !conversation.id) {
            return;
        }

        for (i = 0; i < state.conversations.length; i += 1) {
            if (state.conversations[i].id === conversation.id) {
                state.conversations[i] = conversation;
                state.conversations.sort(compareConversations);
                return;
            }
        }

        state.conversations.push(conversation);
        state.conversations.sort(compareConversations);
    }

    function applyCurrentConversationData() {
        var conversation = getCurrentConversation();
        renderConversationHeader(conversation);
        renderMeta(conversation);
        renderSenderSelect(conversation);
        setComposerEnabled(!!conversation);
    }

    function request(options) {
        var method = options.method || 'GET';
        var ajaxOptions = {
            url: options.url,
            type: method,
            dataType: 'json',
            data: options.data || {}
        };

        if (String(method).toUpperCase() !== 'GET') {
            ajaxOptions.headers = {
                'X-CSRF-Token': getCsrfToken()
            };
        }

        return $.ajax(ajaxOptions);
    }

    function loadMessages() {
        var conversation = getCurrentConversation();
        if (!conversation || state.isLoadingMessages) {
            return;
        }

        state.isLoadingMessages = true;
        updateConnectionStatus('warning', TEXT.statusUpdating);

        request({
            url: endpoints.messages,
            method: 'GET',
            data: {
                userAId: conversation.userA.id,
                userBId: conversation.userB.id
            }
        }).done(function (response) {
            if (!response || response.success !== true) {
                reportConnectionError(TEXT.errorLoadMessages);
                return;
            }

            if (response.conversation) {
                upsertConversation(response.conversation);
            }

            renderConversationList();
            applyCurrentConversationData();
            renderMessages(response.messages || [], getCurrentConversation());
            updateConnectionStatus(null, TEXT.statusConnected);
        }).fail(function () {
            reportConnectionError(TEXT.errorLoadMessages);
        }).always(function () {
            state.isLoadingMessages = false;
        });
    }

    function selectConversation(conversationId, withMessages) {
        var conversation = findConversationById(conversationId);
        if (!conversation) {
            return;
        }

        state.selectedId = conversation.id;
        renderConversationList();
        applyCurrentConversationData();
        if (withMessages) {
            loadMessages();
        }
    }

    function loadConversations(reloadMessages) {
        var previousSelectedId = state.selectedId;
        if (state.isLoadingConversations) {
            return;
        }

        state.isLoadingConversations = true;
        updateConnectionStatus('warning', TEXT.statusUpdating);

        request({
            url: endpoints.conversations,
            method: 'GET',
            data: {
                query: $.trim(dom.$searchInput.val() || '')
            }
        }).done(function (response) {
            var selectedStillExists = false;
            var index;

            if (!response || response.success !== true) {
                reportConnectionError(TEXT.errorLoadConversations);
                return;
            }

            state.conversations = response.conversations || [];
            state.conversations.sort(compareConversations);

            if (state.selectedId) {
                for (index = 0; index < state.conversations.length; index += 1) {
                    if (state.conversations[index].id === state.selectedId) {
                        selectedStillExists = true;
                        break;
                    }
                }
            }

            if (!selectedStillExists) {
                state.selectedId = state.conversations.length ? state.conversations[0].id : null;
            }

            renderConversationList();
            applyCurrentConversationData();

            if (reloadMessages && state.selectedId) {
                loadMessages();
            } else if (!state.selectedId) {
                renderMessages([], null);
            } else if (previousSelectedId !== state.selectedId) {
                loadMessages();
            }

            updateConnectionStatus(null, TEXT.statusConnected);
        }).fail(function () {
            reportConnectionError(TEXT.errorLoadConversations);
        }).always(function () {
            state.isLoadingConversations = false;
        });
    }

    function sendMessage() {
        var conversation = getCurrentConversation();
        var text = $.trim(dom.$messageInput.val() || '');
        var fromUserId = parseInt(dom.$senderSelect.val() || 0, 10);
        var toUserId;
        var maxLength = parseInt(config.maxTextLength || 1000, 10);

        if (!conversation || state.isSending) {
            return;
        }

        if (!text.length) {
            return;
        }

        if (text.length > maxLength) {
            showNotification('error', TEXT.errorMessageTooLong);
            return;
        }

        if (fromUserId === parseInt(conversation.userA.id, 10)) {
            toUserId = parseInt(conversation.userB.id, 10);
        } else if (fromUserId === parseInt(conversation.userB.id, 10)) {
            toUserId = parseInt(conversation.userA.id, 10);
        } else {
            showNotification('error', TEXT.errorInvalidSender);
            return;
        }

        state.isSending = true;
        dom.$sendButton.prop('disabled', true);

        request({
            url: endpoints.send,
            method: 'POST',
            data: {
                fromUserId: fromUserId,
                toUserId: toUserId,
                text: text
            }
        }).done(function (response) {
            if (!response || response.success !== true) {
                showNotification('error', (response && response.message) ? response.message : TEXT.errorSendMessage);
                return;
            }

            dom.$messageInput.val('');
            upsertConversation(response.conversation);

            if (response.conversation && response.conversation.id) {
                state.selectedId = response.conversation.id;
            }

            renderConversationList();
            applyCurrentConversationData();
            loadMessages();
            loadConversations(false);
        }).fail(function (xhr) {
            var response = xhr && xhr.responseJSON ? xhr.responseJSON : null;
            showNotification('error', response && response.message ? response.message : TEXT.errorSendMessage);
        }).always(function () {
            state.isSending = false;
            dom.$sendButton.prop('disabled', false);
            if (!dom.$messageInput.prop('disabled')) {
                dom.$messageInput.focus();
            }
        });
    }

    function startPolling() {
        var interval = parseInt(config.pollInterval || 15000, 10);
        if (interval < 5000) {
            interval = 5000;
        }

        if (state.pollTimer) {
            clearInterval(state.pollTimer);
        }

        state.pollTimer = setInterval(function () {
            loadConversations(true);
        }, interval);
    }

    function bindEvents() {
        dom.$searchForm.on('submit', function (event) {
            event.preventDefault();
            loadConversations(true);
        });

        dom.$refresh.on('click', function () {
            loadConversations(true);
        });

        dom.$conversationList.on('click', '.aac__conversation', function () {
            var conversationId = $(this).data('conversationId');
            selectConversation(conversationId, true);
        });

        dom.$sendForm.on('submit', function (event) {
            event.preventDefault();
            sendMessage();
        });

        dom.$messageInput.on('keydown', function (event) {
            if (event.keyCode === 13 && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
        });

        dom.$senderSelect.on('change', function () {
            var conversation = getCurrentConversation();
            if (conversation && state.currentMessages.length) {
                renderMessages(state.currentMessages, conversation);
            }
        });

        $(window).on('beforeunload', function () {
            if (state.pollTimer) {
                clearInterval(state.pollTimer);
            }
        });
    }

    function init() {
        bindEvents();
        setComposerEnabled(false);
        renderConversationHeader(null);
        renderMeta(null);
        renderMessages([], null);
        loadConversations(true);
        startPolling();
    }

    init();
})(window.jQuery);
