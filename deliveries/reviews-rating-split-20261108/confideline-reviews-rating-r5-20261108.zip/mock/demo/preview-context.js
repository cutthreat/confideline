(function () {
  'use strict';
  const query = new URLSearchParams(location.search),role = query.get('role') || (document.body.dataset.page === 'reviews' ? 'moderator' : 'superadmin'),lang = query.get('lang') === 'en' ? 'en' : 'ru';
  const labels = {
    event_approve:['Отзыв одобрен','Review Approved'],event_reject:['Отзыв отклонён','Review Rejected'],event_hide:['Отзыв скрыт','Review Hidden'],event_restore:['Отзыв восстановлен','Review Restored'],event_delete:['Отзыв удалён','Review Deleted'],event_appeal_publish:['Опубликован после пересмотра','Published After Reconsideration'],event_appeal_decline:['Решение оставлено в силе','Decision Upheld'],
    history:['История','History'],historyTitle:['История модерации','Moderation History'],close:['Закрыть','Close'],revise:['Текст исправлен клиентом','Text Revised by Client'],appealEvent:['Запрошен пересмотр','Reconsideration Requested'],noHistory:['Решений модерации пока нет.','No Moderation Decisions Yet.'],
    reviews:['Отзывы','Reviews'],overallRating:['Общий рейтинг','Overall Rating'],reviewDetailCalculation:['Расчёт рейтинга','Rating calculation'],reviewDetailEntries:['Отзывы и оценки','Reviews and ratings'],reviewDetailAuthor:['Автор','Author'],write:['Написать отзыв','Write a Review'],moderation:['Модерация отзывов','Review Moderation'],create:['Новый отзыв','New Review'],reviewSettings:['Настройки отзывов','Review Settings'],textColumn:['Текст отзыва','Review Text'],
    superadmin:['Супер-администратор','Super Administrator'],moderator:['Модератор','Moderator'],client:['Клиент','Client'],forbidden:['Доступ запрещён','Access Denied'],
    all:['Все','All'],pending:['На проверке','Pending'],published:['Опубликован','Published'],hidden:['Скрыт','Hidden'],rejected:['Отклонён','Rejected'],deleted:['Удалён','Deleted'],
    expert:['Эксперт','Expert'],author:['Профиль клиента','Client Profile'],selectAuthor:['Выберите профиль','Select a Profile'],stars:['Оценка','Rating'],text:['Текст отзыва (необязательно)','Review Text (Optional)'],
    anonymous:['Анонимно','Anonymous'],reason:['Причина','Reason'],createReason:['Основание добавления','Reason for Creation'],cancel:['Отмена','Cancel'],confirm:['Подтвердить','Confirm'],save:['Сохранить','Save'],
    submit:['Отправить на проверку','Submit for Review'],publish:['Опубликовать','Publish'],sent:['Отзыв отправлен на проверку. Он появится в анкете после одобрения модератором.','Your review was submitted for moderation. It will appear after approval.'],
    ratingSent:['Оценка отправлена на проверку. Она будет учтена после одобрения модератором.','Your rating was submitted for moderation. It will be counted after approval.'],
    posted:['Отзыв опубликован. Спасибо!','Your review has been published. Thank you!'],ratingPosted:['Оценка учтена. Спасибо!','Your rating has been counted. Thank you!'],
    again:['Написать ещё','Write Another'],queue:['К очереди отзывов','Back to Reviews'],audit:['Закрытый журнал действий','Restricted Audit Log'],noActions:['Действий пока нет.','No Actions Yet.'],
    approve:['Одобрить','Approve'],reject:['Отклонить','Reject'],hide:['Скрыть','Hide'],restore:['Восстановить','Restore'],delete:['Удалить','Delete'],empty:['Отзывы не найдены.','No Reviews Found.'],
    noText:['Без комментария','No Comment'],anonymousPublic:['Анонимный клиент','Anonymous Client'],checked:['Проверен','Verified'],notChecked:['Не проверен','Not Verified'],
    noConsultation:['Не привязана','Not Linked'],date:['Отзыв / дата','Review / Date'],person:['Клиент / эксперт','Client / Expert'],consultation:['Консультация','Consultation'],status:['Статус','Status'],actions:['Действия','Actions'],
    search:['Клиент, отзыв или консультация','Client, Review or Consultation'],reset:['Сбросить фильтры','Reset Filters'],rating:['Рейтинг','Rating'],votes:['Голосов','Votes'],texts:['Текстовых отзывов','Text Reviews'],
    auto:['Автоматический','Automatic'],manual:['С ручной базой','With Manual Base'],setRating:['Задать рейтинг','Set Rating'],ratingTitle:['Рейтинг эксперта','Expert Rating'],ratingSource:['Расчёт рейтинга','Rating Calculation'],
    autoSource:['Только опубликованные оценки','Published Ratings Only'],manualSource:['С учётом ручной базы','Include Manual Base'],manualRating:['Рейтинг базы','Base Rating'],manualVotes:['Голосов в базе','Base Vote Count'],ratingReason:['Причина изменения','Reason for Change'],
    publishedRatings:['Опубликованные оценки','Published Ratings'],ratingBase:['Ручная база','Manual Base'],totalRating:['Итог','Total'],
    editRatingBase:['Ручное управление','Manual Management'],expertProfile:['Анкета эксперта','Expert Profile'],
    moderationMode:['Режим модерации отзывов и оценок','Review and Rating Moderation Mode'],premoderation:['Предмодерация','Premoderation'],postmoderation:['Постмодерация','Postmoderation'],none:['Без модерации','No Moderation'],moderationError:['Выберите режим модерации.','Select a Moderation Mode.'],awaitingPostmoderation:['Опубликован · ожидает проверки','Published · Awaiting Review'],moderationAudit:['Журнал модерации','Moderation Log'],
    appeal:['На пересмотре','Reconsideration'],appeal_publish:['Опубликовать после пересмотра','Publish After Reconsideration'],appeal_decline:['Оставить решение в силе','Uphold Decision'],internalReason:['Внутренняя причина','Internal Reason'],clientDecision:['Причина для клиента','Reason Shown to the Client'],clientMessage:['Комментарий клиенту (обязателен для другой причины)','Client Comment (Required for Another Reason)'],appealReply:['Ответ клиенту','Reply to the Client'],clientReasonError:['Выберите причину для клиента; для другой причины напишите объяснение до 500 символов.','Choose a Client Reason; Explain Another Reason in up to 500 Characters.'],appealPending:['Сначала рассмотрите запрос пересмотра.','Resolve the Reconsideration Request First.'],reviewConflict:['Запись изменилась. Причина сохранена. Закройте диалог и откройте актуальную запись.','The Submission Changed. Your Reason Is Preserved. Close This Dialog and Open the Current Submission.'],
    settings:['Настройки публикации','Publication Settings'],requireModeration:['Модерация новых отзывов и оценок','Moderate New Reviews and Ratings'],on:['Включена','On'],off:['Выключена','Off'],
    siteDisplay:['Отображение на сайте','Site Display'],showReviews:['Показывать отзывы на сайте','Show Reviews on the Website'],showRating:['Показывать рейтинг и число голосов','Show Rating and Vote Count'],showTexts:['Показывать тексты отзывов','Show Review Texts'],
    intakePublication:['Приём и публикация','Submission and Publication'],acceptClientReviews:['Принимать новые отзывы клиентов','Accept New Client Reviews'],reviewForm:['Форма отзыва','Review Form'],allowAnonymous:['Разрешить анонимные отзывы','Allow Anonymous Reviews'],allowRatingOnly:['Разрешить оценку без комментария','Allow Ratings Without Comments'],maxTextLength:['Максимум символов в отзыве','Maximum Review Length'],
    textRequiredLabel:['Текст отзыва','Review Text'],textRequired:['Добавьте текст отзыва.','Add Review Text.'],anonymousDisabled:['Анонимные отзывы отключены. Снимите флажок, чтобы продолжить.','Anonymous Reviews Are Disabled. Clear the Checkbox to Continue.'],submissionsClosed:['Приём отзывов сейчас закрыт.','Review Submissions Are Currently Closed.'],
    textLimitError:['Укажите целый лимит от 1 до 5000 символов.','Enter an Integer Limit from 1 to 5000 Characters.'],visibilityError:['Включите показ рейтинга или текстов либо отключите отзывы на сайте.','Enable Rating or Review Text Display, or Disable Website Reviews.'],
    settingsConflict:['Настройки изменены в другой вкладке. Загрузите актуальные значения.','Settings Changed in Another Tab. Load the Current Values.'],reloadSettings:['Загрузить сохранённые настройки','Load Saved Settings'],unsavedChanges:['Есть несохранённые изменения','Unsaved Changes'],
    ratingConflict:['База рейтинга изменена в другой вкладке. Черновик сохранён. Загрузите актуальную базу перед сохранением.','The Rating Base Changed in Another Tab. Your Draft Is Preserved. Load the Current Base Before Saving.'],reloadRating:['Загрузить актуальную базу рейтинга','Load the Current Rating Base'],
    settingsSaved:['Настройки сохранены.','Settings Saved.'],decisionSaved:['Решение сохранено.','Decision Saved.'],ratingSaved:['Расчёт рейтинга сохранён.','Rating Calculation Saved.'],
    storage:['Не удалось прочитать или сохранить данные. Изменения не выполнены.','Data Could Not Be Read or Saved. No Changes Applied.'],
    appealReplyError:['Напишите ответ клиенту до 500 символов.','Write a Reply to the Client of up to 500 Characters.'],
    error:['Проверьте заполнение полей.','Check the Form Fields.'],authorError:['Выберите действующий профиль клиента.','Select an Active Client Profile.'],starsError:['Выберите оценку от 1 до 5.','Select a Rating from 1 to 5.'],textError:['Текст не должен превышать 1000 символов.','Text Must Not Exceed 1000 Characters.'],reasonError:['Укажите причину до 500 символов.','Enter a Reason of up to 500 Characters.'],
    votesError:['Укажите целое неотрицательное число голосов.','Enter a Non-negative Integer Vote Count.'],ratingError:['Рейтинг: 1.0–5.0, шаг 0.1.','Rating: 1.0–5.0, Step 0.1.'],conflict:['Данные изменились. Обновите список и повторите решение.','Data Changed. Refresh the List Before Retrying.']
  };
  const t = key => labels[key] ? labels[key][lang === 'en' ? 1 : 0] : key;
  const esc = value => String(value).replace(/[&<>"']/g,c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const url = file => file + '?role=' + encodeURIComponent(role) + '&lang=' + lang;
  const can = action => ReviewAdminWorkflow.permissions(role).includes(action);
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  let store;
  try {
    if(document.body.dataset.page==='rating' && query.get('reviews')==='50'){
      const fixture=ReviewAdminWorkflow.initialState();
      for(let i=0;i<48;i++){
        const author=['Ирина','Александр','Анна'][i%3];
        const text=lang==='en' ? 'The expert answered my questions and helped me decide what to do next.' :
          'Эксперт ответил на мои вопросы и помог определиться, что делать дальше.';
        fixture.reviews.push({id:'RV-'+fixture.nextId++,expertId:'EX-101',author,stars:3+i%3,
          text:i===47 ? Array(10).fill(text).join('\n\n') : text,anonymous:false,status:'published',
          createdAt:new Date(Date.UTC(2026,9,i+1,10)).toISOString()});
      }
      let raw=JSON.stringify(fixture);
      store=ReviewAdminWorkflow.create({getItem:()=>raw,setItem:(_,value)=>{raw=value;}});
    }
    else if(query.has('history')){let raw=JSON.stringify(ReviewAdminWorkflow.historyExample());store=ReviewAdminWorkflow.create({getItem:()=>raw,setItem:(_,value)=>{raw=value;}});}
    else store = ReviewAdminWorkflow.create({getItem:key=>localStorage.getItem('review-split-20261107:'+key),setItem:(key,value)=>localStorage.setItem('review-split-20261107:'+key,value)});
  } catch (_) { store = ReviewAdminWorkflow.create({getItem:()=>{throw new Error('storage');}}); }
  function error(error) {
    if(error.message==='text'){try{const limit=store.settings().maxTextLength;return lang==='en'?'Text Must Not Exceed '+limit+' Characters.':'Текст не должен превышать '+limit+' символов.';}catch(_){return t('storage');}}
    return t(({author:'authorError',stars:'starsError',moderation:'moderationError',text_required:'textRequired',anonymous_disabled:'anonymousDisabled',submissions_closed:'submissionsClosed',text_limit:'textLimitError',visibility:'visibilityError',settings_conflict:'settingsConflict',rating_conflict:'ratingConflict',review_conflict:'reviewConflict',client_reason:'clientReasonError',appeal_pending:'appealPending',appeal_reply:'appealReplyError',reason:'reasonError',rating:'ratingError',votes:'votesError',storage:'storage',transition:'conflict',forbidden:'forbidden'})[error.message] || 'error');
  }
  addEventListener('storage',event=>{const prefix='review-split-20261107:';if(!event.key?.startsWith(prefix))return;event.stopImmediatePropagation();dispatchEvent(new StorageEvent('storage',{key:event.key.slice(prefix.length),oldValue:event.oldValue,newValue:event.newValue,url:event.url}));});
  window.ReviewAdminUI={role,lang,t,esc,url,can,store,error};
})();
