# Игорю: баланс и финансы — исправленный комплект r4

Сохраняем отдельные баланс, Мои выплаты, карточку и реквизиты. Для трёх экранов выплат принят доработанный компонент с карточкой баланса/запроса и отдельной историей; упрощённую заменуv9 не использовать. Общая шапка/логотип/меню/footer — существующие, без global_custom и общего shared-admin.

## Исправление r4: действующий сайт — эталон исходных компонентов

Для «Заказов», «Операций баланса» и таблицы «Мой баланс» сохранены составные ячейки действующего сайта: пользователь/логин/аватар, GUID с копированием, кредитные и статусные бейджи, значки оплаты, знаки/цвета сумм, разные типы операций и множественный фильтр типов. Меняются только согласованные короткие подписи RU/EN. Не заменять эти рабочие компоненты универсальными текстовыми td из прежней v9.

В preview подменены только значения демонстрационных записей. Сумма заказа — независимое значение, не результат credits × ставки выплаты. reference-grid-preview.js и reference-avatar.png нужны только локальному макету; на сайт их не переносить. Общие CSS, global_custom, контроллеры, AssetBundle, расчёты и зарегистрированные виджеты сохраняются. Остальные пять страниц поставки r3 оставлены побайтно прежними, включая доработанные выплаты и партнёров.

## Какой источник у каждой страницы

| Экран | Источник |
|---|---|
| Мой баланс | Owner-designated current live DOM 2026-10-25; nested components retained, fixture leaf values anonymized; approved RU/EN headings only |
| Операции баланса | Owner-designated current live DOM 2026-10-25; nested components retained, fixture leaf values anonymized; approved RU/EN headings only |
| Заказы | Owner-designated current live DOM 2026-10-25; nested components retained, fixture leaf values anonymized; approved RU/EN headings only |
| Реестр выплат | current manual-payout register + approved RU/EN |
| Мои выплаты | polished finance-headings-v6 payout component + later approved short headings/shared date range |
| Карточка выплаты | polished finance-headings-v6 payout card + deterministic current fixtures |
| Реквизиты | polished finance-headings-v6 payout form |
| Партнёры | unchanged current site reference, owner instruction25.10 |

Машиночитаемая карта — PAGES-AND-APPROVALS.json. Пять финансовых таблиц имеют только утверждённые EN-заголовки, остальные тексты не объявляются полностью переведёнными.

## Что брать для интеграции

1. HEADINGS-RU-EN.json, FINANCE-TABLE-HEADINGS-RU-EN.md и TABLE-FIELDS.json — короткие подписи, полные доступные имена и порядок пяти существующих GridView. Применять через i18n, сохраняя sorting links, filter names и controller. Подсказки hover/focus, Escape; клиент=Customer, владелец=Owner, Было=Before, USD=сумма получателю, Система=Provider.
2. payout-feature.css — только восстановленные история/запрос, карточка и реквизиты, уникальный #cl-my-payouts. Все селекторы ограничены этим корнем. В общий реестр, баланс, операции, заказы и партнёров этот CSS не подключать. Штатные CSS сайта не менять.
3. Три partial: my-payouts.partial.html, my-payout-view.partial.html, my-payout-details.partial.html. Встраивать по одному внутрь штатной content-wrapper; второй content-wrapper не создавать. Это образцы разметки с placeholders, не готовые PHP views. Значения/eligibility/disabled/порог/курс/комиссия — из текущих моделей и сервера.
4. my-payouts-ui.js — прежний UI-адаптер синхронизации локальной прокрутки. Связать init/dispose с действующим lifecycle/PJAX, не дублировать обработчики. Финансовый controller/источники/запросы не заменять.
5. Период — существующий finance-date-filter с form-control, calendar/clear и DateRangePicker/Krajee. Сохранить штатное применение финансовых фильтров. Два native-date и min-width1120 не возвращать; локальная прокрутка на узком экране допустима.
6. Формы: PayoutActionForm[method], существующий request key, POST/CSRF и idempotency; PayoutDetailsForm[countryCode], nameAndFamily, walletCapitalistIsActive/Number, walletPaySeraIsActive/Number, walletAdvCashIsActive/Number. Полный список стран, доступность методов и суммы берутся из приложения; демо-данные не копировать как бизнес-константы.
7. Сохранить действующий confirm, отмену без эффекта, отказ чужому wallet/ID и одно ledger-событие при повторе/параллельном запросе. Approval и фактическая выплата — разные факты. Клиентским JS деньги/курс/округление не вычислять.

## Что не переносить

preview/assets и demo helpers, restored-payouts-preview.js, payout-period-preview.js, payout-headings.js, preview-grid.js, period-preview.js, payout-detail-preview.js, viewer.js — только автономный макет. Не переносить шапку, vendor/theme, global_custom, shared-admin, отозванный partner-layout или новое окно начисления. Production deploy, реальные деньги и реквизиты этим комплектом не изменялись.

## Проверка

Открыть index.html: восемь отдельных макетов,5 EN-вариантов и ready/empty/error. Пройти ACCEPTANCE.xlsx: build/commit → роль → исходные данные → действие → ожидаемое → факт → доказательство. Backend/RBAC/ledger, реальные финансовые запросы и41 live-проверка — отдельная приёмка; CSS viewport не является физическим телефоном.
