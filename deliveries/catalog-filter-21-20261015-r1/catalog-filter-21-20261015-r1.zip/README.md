# Фильтр экспертов — комплект для Игоря

Требования: TZ.md.
Макеты: https://cutthreat.github.io/confideline/deliveries/catalog-filter-21-20261015-r1/current-site/catalog-filter.html и https://cutthreat.github.io/confideline/deliveries/catalog-filter-21-20261015-r1/current-site/catalog-filter-auth.html.

Для переноса — только integration/. `_filter.php` — partial рабочего блока; `CatalogFilterAsset.php` — отдельный bundle, CSS и JS лежат в assets/catalog-filter/. Namespace, URL поиска, имена полей и namespace bundle темы адаптируются к действующему приложению. В depends добавляется действующий AssetBundle темы: новый CSS должен идти после штатного, а не заменять его. Шрифт и FontAwesome берутся из существующей темы; новые глобальные библиотеки не нужны.

В partial передаются $searchUrl, $selected (areas/topics) и необязательный $total; для повторных экземпляров — разные $id. Пример GET-формы не предписывает backend или API. Если используется PJAX, partial должен обновляться вместе с результатом: выбранные условия, счётчик и карточки относятся к одной выдаче. Обработчики и загрузка данных сайта не дублируются. Передача этого блока не означает, что интеграция с Yii2/production уже выполнена.

В архиве нет шапки, меню, CSS темы, тестовых профилей, демонстрационного renderer или старой горизонтальной версии. SOURCE-CSS.json фиксирует исходную страницу и CSS для сверки, а не для повторного подключения.
